# Stage Direction, Static Framing, Speaker Focus & Room Lighting
# Implements the visual novel staging principles from "LEVEL UP Your Visual Novel Sprites!":
#   1. Theater Staging: Automatic speaker focus (active speaker pops, listeners dim) & asymmetric slots
#   2. Static Expression Framing: 27 character expression definitions with zero motion and bottom-anchored framing
#   3. Film Framing Techniques: Waist-up vs. Bust close-ups (1.42x), imposing whale scale, & static camera framing
#   4. Lighting & Framing: Automatic room-lighting tints on 24k gold sprites + Burnout >= 60 desaturation
#   5. Show-Don't-Tell Blocking: Whisper aside framing & dead-equity ghost tint — all static with zero motion or bottom gaps

################################################################################
## 1. Speaker Focus & Environment Lighting State

default _active_speaker = None
default _lab_room_tint_enabled = True
default _lab_speaker_focus_enabled = True
default _lab_override_bg = None

init -5 python:
    import math

    # Map Character `name` (or image tag) to canonical sprite tag
    CHAR_TAG_MAP = {
        "Koraba": "ashel",
        "Clara": "laylay",
        "Xochit": "xochtl",
        "Maya": "maya",
        "Jordan": "jordan",
        "Alex": "alex",
        "Vera": "vera",
        "Spectre": "spectre",
        "Atlas": "atlas",
    }

    ALL_CHAR_TAGS = ("ashel", "laylay", "xochtl", "maya", "jordan", "alex", "vera", "spectre", "atlas")

    # Room lighting profiles (r_mul, g_mul, b_mul, bright_offset, contrast_mul)
    # Calibrated for both rustic line-art/watercolor sprites and legacy sprites.
    ROOM_LIGHTING = {
        "sanctuary":     (1.02, 0.99, 0.94,  0.01, 1.02),  # Warm sunlit ochre sanctuary
        "treasury_fire": (1.06, 0.92, 0.90, -0.02, 1.08),  # High-contrast crimson crisis light
        "cacao_circle":  (1.03, 0.98, 0.93,  0.01, 1.02),  # Warm candle & ceremonial cacao glow
        "apothecary":    (0.98, 1.01, 0.96,  0.00, 1.03),  # Herbal apothecary & ledger room
        "constellation": (0.96, 0.97, 1.02,  0.00, 1.04),  # Star-chart night canvas
        "coworking":     (1.00, 0.99, 0.96,  0.00, 1.00),  # Warm natural daylight studio
        "conference":    (1.02, 0.98, 0.92,  0.01, 1.04),  # Crisp stage spotlights
        "showcase_backstage": (1.00, 0.98, 0.94,  0.00, 1.02),  # Warm practical venue work lights with stage spill
        "lisbon_airport": (0.97, 0.99, 1.02, -0.01, 1.02),  # Cool rainy terminal light
        "apartment":     (0.84, 0.93, 1.08, -0.05, 1.06),  # 2:47 AM cool midnight monitor glow
        "discord":       (0.95, 0.92, 1.08,  0.00, 1.05),  # Neon cyan/magenta server ambiance
        "blockchain":    (0.88, 0.98, 1.06, -0.02, 1.10),  # High-contrast cyber node glow
        "rooftop":       (1.06, 0.95, 0.88,  0.03, 1.04),  # Golden hour / dawn rose-gold warmth
        "signing":       (0.90, 1.02, 0.94, -0.03, 1.08),  # Hardware wallet emerald/terminal glow
        "factionmap":    (0.96, 0.94, 0.90, -0.02, 1.05),  # War-room tactical table light
    }

    # Expression-specific subtle lighting modifiers (bright_delta, sat_mul, contrast_mul)
    EXPR_LIGHTING = {
        "neutral":     ( 0.00, 1.00, 1.00),
        "hyped":       ( 0.04, 1.08, 1.04),
        "proud":       ( 0.03, 1.05, 1.03),
        "determined":  ( 0.03, 1.05, 1.05),
        "generous":    ( 0.04, 1.06, 1.02),
        "focused":     ( 0.01, 1.02, 1.08),
        "calculating": ( 0.00, 0.98, 1.12),
        "smirk":       ( 0.02, 1.04, 1.06),
        "wry":         ( 0.02, 1.02, 1.05),
        "sincere":     ( 0.03, 1.04, 1.00),
        "warm":        ( 0.04, 1.06, 1.00),
        "tired":       (-0.07, 0.82, 0.95),
        "exhausted":   (-0.09, 0.78, 0.94),
        "hurt":        (-0.06, 0.84, 0.96),
        "vulnerable":  (-0.05, 0.86, 0.96),
        "defensive":   (-0.02, 0.90, 1.10),
        "guarded":     (-0.03, 0.90, 1.12),
        "stern":       (-0.02, 0.92, 1.12),
        "alarmed":     ( 0.05, 1.06, 1.12),
        "alert":       ( 0.04, 1.04, 1.12),
        "predatory":   (-0.04, 0.94, 1.20),
        "typing":      ( 0.02, 1.02, 1.08),
    }

    def get_current_room_bg():
        """Return the active background attribute (e.g., 'apartment', 'conference')."""
        if getattr(store, "_lab_override_bg", None):
            return store._lab_override_bg
        try:
            attrs = renpy.get_attributes("bg", layer="master")
            if attrs:
                return attrs[0]
        except Exception:
            pass
        return "conference"

    def get_showing_characters():
        """Return list of character tags currently visible on the master layer."""
        try:
            tags = renpy.get_showing_tags(layer="master")
            return [c for c in ALL_CHAR_TAGS if c in tags]
        except Exception:
            return []

    def clear_active_speaker_on_scene(layer):
        """Avoid carrying the previous scene's speaker focus into a new lineup."""
        if layer == "master":
            store._active_speaker = None

    config.scene_callbacks.append(clear_active_speaker_on_scene)

    def ease_focus_zoom(trans, target_zoom, at):
        """Ease focus scale changes quickly at first, then gently into place."""
        duration = 0.40
        previous_target = getattr(trans, "_focus_zoom_target", None)

        if previous_target is None:
            # Establish the initial size before the sprite first renders. The
            # tween is reserved for later focus changes, avoiding an entry shrink.
            trans._focus_zoom_from = target_zoom
            trans._focus_zoom_target = target_zoom
            trans._focus_zoom_start = at
            return target_zoom
        elif abs(previous_target - target_zoom) > 0.0001:
            start = trans._focus_zoom_start
            progress = max(0.0, min(1.0, (at - start) / duration))
            eased = 1.0 - (1.0 - progress) ** 3
            trans._focus_zoom_from = trans._focus_zoom_from + (previous_target - trans._focus_zoom_from) * eased
            trans._focus_zoom_target = target_zoom
            trans._focus_zoom_start = at

        progress = max(0.0, min(1.0, (at - trans._focus_zoom_start) / duration))
        eased = 1.0 - (1.0 - progress) ** 3
        return trans._focus_zoom_from + (trans._focus_zoom_target - trans._focus_zoom_from) * eased

    def char_focus_light_fn(trans, st, at, char_tag="maya", expr_name="neutral"):
        """Static transform function that applies speaker focus (zoom, brightness,
        saturation) and room + expression lighting with zero motion or bottom gaps."""
        # Determine showing characters (or Stage Lab override)
        showing = getattr(store, "_lab_showing_chars", None)
        if showing is None:
            showing = get_showing_characters()
        multi_stage = len(showing) >= 2
        active = getattr(store, "_active_speaker", None)
        speaker_visible = active in showing if active is not None else False
        focus_on = getattr(store, "_lab_speaker_focus_enabled", True)

        # Target focus values (no yoffset so bottom edge never lifts off the screen)
        dim_mul = 1.0
        if not focus_on:
            t_zoom, t_bright, t_sat = 1.0, 0.0, 1.0
        elif speaker_visible and active == char_tag:
            if multi_stage:
                t_zoom, t_bright, t_sat = 1.025, 0.06, 1.08
            else:
                t_zoom, t_bright, t_sat = 1.0, 0.02, 1.02
        elif speaker_visible and active != char_tag and multi_stage:
            # Another character is speaking in a multi-character scene -> dim listener clearly
            t_zoom, t_bright, t_sat = 1.0, -0.08, 0.78
            dim_mul = 0.72
        elif active is None and multi_stage:
            # Narrator or player speaking while multiple characters are on stage
            t_zoom, t_bright, t_sat = 1.0, -0.06, 0.88
            dim_mul = 0.80
        else:
            t_zoom, t_bright, t_sat = 1.0, 0.0, 1.0

        # Expression lighting modifier
        eb, es, ec = EXPR_LIGHTING.get(expr_name, (0.0, 1.0, 1.0))

        # Room ambient lighting modifier
        if getattr(store, "_lab_room_tint_enabled", True):
            room = get_current_room_bg()
            rr, rg, rb, r_bright, r_cont = ROOM_LIGHTING.get(room, (1.0, 1.0, 1.0, 0.0, 1.0))
        else:
            rr, rg, rb, r_bright, r_cont = (1.0, 1.0, 1.0, 0.0, 1.0)

        # Spectre typing gets a subtle cyan terminal screen reflection
        if expr_name == "typing":
            rr, rg, rb = rr * 0.88, rg * 1.04, rb * 1.12

        rr, rg, rb = rr * dim_mul, rg * dim_mul, rb * dim_mul

        final_bright = t_bright + eb + r_bright
        final_sat    = t_sat * es
        final_cont   = ec * r_cont

        tint_hex = "#%02x%02x%02x" % (
             max(0, min(255, int(rr * 255))),
             max(0, min(255, int(rg * 255))),
             max(0, min(255, int(rb * 255))),
        )

        # Overcompensate by +2px at the bottom so window scaling across resolutions
        # never exposes a 1px seam between the sprite and the bottom of the screen.
        trans.zoom = ease_focus_zoom(trans, t_zoom, at)
        trans.yoffset = 2
        trans.xoffset = 0
        trans.matrixcolor = (
            TintMatrix(tint_hex)
            * SaturationMatrix(final_sat)
            * ContrastMatrix(final_cont)
            * BrightnessMatrix(final_bright)
        )
        return 0.05

    def char_focus_and_light(char_tag, expr_name="neutral"):
        return Transform(function=renpy.curry(char_focus_light_fn)(char_tag=char_tag, expr_name=expr_name))

## Attach speaker tracking to the Character objects defined in script.rpy
init 5 python:
    SPEAKER_ZORDER = 10

    def raise_speaker_zorder(speaker_tag):
        """Pop the speaking character above the other sprites by re-showing it with a
        higher zorder (Ren'Py zorder is fixed at show time; transforms can't change it).
        Re-showing with the same attributes and no `at` keeps position, transform and
        focus tween state. Everyone else drops back to zorder 0."""
        try:
            showing = get_showing_characters()
            if speaker_tag not in showing:
                return
            current = dict(renpy.get_zorder_list("master"))
            for tag in showing:
                want = SPEAKER_ZORDER if tag == speaker_tag else 0
                if current.get(tag, 0) != want:
                    attrs = renpy.get_attributes(tag, layer="master") or ()
                    renpy.show((tag,) + tuple(attrs), zorder=want, layer="master")
        except Exception:
            pass

    def direction_all_char_callback(event, interact=True, _speaker_tag=None, **kwargs):
        if event == "begin" and interact:
            store._active_speaker = _speaker_tag
            if _speaker_tag is not None:
                raise_speaker_zorder(_speaker_tag)

    def _wire_speaker_callbacks():
        mapping = [
            ("ashel", "ashel"),
            ("laylay", "laylay"),
            ("xochtl", "xochtl"),
            ("m", "maya"),
            ("j", "jordan"),
            ("a", "alex"),
            ("v", "vera"),
            ("s", "spectre"),
            ("w", "atlas"),
            ("pc", None),
            ("narrator", None),
            ("mod", None),
        ]
        for var_name, tag in mapping:
            ch = getattr(store, var_name, None)
            if ch is not None and hasattr(ch, "cb_args") and hasattr(ch, "display_args"):
                new_cb_args = dict(ch.cb_args) if ch.cb_args else {}
                new_cb_args["_speaker_tag"] = tag
                ch.cb_args = new_cb_args
                ch.display_args["callback"] = direction_all_char_callback

    _wire_speaker_callbacks()


################################################################################
## 2. Static Expression Framing
## No rotation (`rotate None`) so Ren'Py never adds `rotate_pad` transparent
## bounding-box padding around the 560x880 sprite, and no motion/bobbing.

transform expr_neutral:
    subpixel True
    yoffset 0 xoffset 0 zoom 1.0

transform expr_hyped:
    subpixel True
    yoffset 0 xoffset 0 zoom 1.02

transform expr_proud:
    subpixel True
    yoffset 0 xoffset 0 zoom 1.025

transform expr_determined:
    subpixel True
    yoffset 0 xoffset 0 zoom 1.025

transform expr_generous:
    subpixel True
    yoffset 0 xoffset 0 zoom 1.03

transform expr_focused:
    subpixel True
    yoffset 0 xoffset -6 zoom 1.03

transform expr_calculating:
    subpixel True
    yoffset 0 xoffset -8 zoom 1.04

transform expr_smirk:
    subpixel True
    yoffset 0 xoffset 8 zoom 1.015

transform expr_wry:
    subpixel True
    yoffset 0 xoffset 4 zoom 1.015

transform expr_tired:
    subpixel True
    yoffset 16 xoffset 0 zoom 0.98

transform expr_exhausted:
    subpixel True
    yoffset 24 xoffset 0 zoom 0.96

transform expr_hurt:
    subpixel True
    yoffset 12 xoffset 10 zoom 0.97

transform expr_vulnerable:
    subpixel True
    yoffset 8 xoffset -8 zoom 0.98

transform expr_defensive:
    subpixel True
    yoffset 2 xoffset 12 zoom 0.98

transform expr_guarded:
    subpixel True
    yoffset 2 xoffset 10 zoom 0.985

transform expr_stern:
    subpixel True
    yoffset 0 xoffset 0 zoom 1.02

transform expr_alarmed:
    subpixel True
    yoffset 0 xoffset 0 zoom 1.025

transform expr_alert:
    subpixel True
    yoffset 0 xoffset 0 zoom 1.02

transform expr_sincere:
    subpixel True
    yoffset 0 xoffset -6 zoom 1.025

transform expr_warm:
    subpixel True
    yoffset 0 xoffset 0 zoom 1.025

transform expr_predatory:
    subpixel True
    yoffset 18 xoffset -10 zoom 1.08

transform expr_typing:
    subpixel True
    yoffset 0 xoffset 0 zoom 1.0


################################################################################
## 3. Bind All 27 Character Expression Images to Their Framing + Lighting Rig

# MAYA (5)
image maya neutral     = At("images/maya neutral.webp",     expr_neutral,     char_focus_and_light("maya", "neutral"))
image maya focused     = At("images/maya focused.webp",     expr_focused,     char_focus_and_light("maya", "focused"))
image maya tired       = At("images/maya tired.webp",       expr_tired,       char_focus_and_light("maya", "tired"))
image maya proud       = At("images/maya proud.webp",       expr_proud,       char_focus_and_light("maya", "proud"))
image maya alarmed     = At("images/maya alarmed.webp",     expr_alarmed,     char_focus_and_light("maya", "alarmed"))

# JORDAN (5)
image jordan neutral    = At("images/jordan neutral.webp",    expr_neutral,    char_focus_and_light("jordan", "neutral"))
image jordan hyped      = At("images/jordan hyped.webp",      expr_hyped,      char_focus_and_light("jordan", "hyped"))
image jordan hurt       = At("images/jordan hurt.webp",       expr_hurt,       char_focus_and_light("jordan", "hurt"))
image jordan determined = At("images/jordan determined.webp", expr_determined, char_focus_and_light("jordan", "determined"))
image jordan exhausted  = At("images/jordan exhausted.webp",  expr_exhausted,  char_focus_and_light("jordan", "exhausted"))

# ALEX (5)
image alex neutral     = At("images/alex neutral.webp",     expr_neutral,     char_focus_and_light("alex", "neutral"))
image alex smirk       = At("images/alex smirk.webp",       expr_smirk,       char_focus_and_light("alex", "smirk"))
image alex calculating = At("images/alex calculating.webp", expr_calculating, char_focus_and_light("alex", "calculating"))
image alex defensive   = At("images/alex defensive.webp",   expr_defensive,   char_focus_and_light("alex", "defensive"))
image alex sincere     = At("images/alex sincere.webp",     expr_sincere,     char_focus_and_light("alex", "sincere"))

# VERA (4)
image vera neutral     = At("images/vera neutral.webp",     expr_neutral,     char_focus_and_light("vera", "neutral"))
image vera wry         = At("images/vera wry.webp",         expr_wry,         char_focus_and_light("vera", "wry"))
image vera stern       = At("images/vera stern.webp",       expr_stern,       char_focus_and_light("vera", "stern"))
image vera warm        = At("images/vera warm.webp",        expr_warm,        char_focus_and_light("vera", "warm"))

# SPECTRE (4)
image spectre neutral    = At("images/spectre neutral.webp",    expr_neutral,    char_focus_and_light("spectre", "neutral"))
image spectre typing     = At("images/spectre typing.webp",     expr_typing,     char_focus_and_light("spectre", "typing"))
image spectre alert      = At("images/spectre alert.webp",      expr_alert,      char_focus_and_light("spectre", "alert"))
image spectre vulnerable = At("images/spectre vulnerable.webp", expr_vulnerable, char_focus_and_light("spectre", "vulnerable"))

# ATLAS (4)
image atlas neutral   = At("images/atlas neutral.webp",   expr_neutral,   char_focus_and_light("atlas", "neutral"))
image atlas generous  = At("images/atlas generous.webp",  expr_generous,  char_focus_and_light("atlas", "generous"))
image atlas guarded   = At("images/atlas guarded.webp",   expr_guarded,   char_focus_and_light("atlas", "guarded"))
image atlas predatory = At("images/atlas predatory.webp", expr_predatory, char_focus_and_light("atlas", "predatory"))

# KORABA (6)
image ashel neutral    = At("images/ashel neutral.webp",    expr_neutral,    char_focus_and_light("ashel", "neutral"))
image ashel focused    = At("images/ashel focused.webp",    expr_focused,    char_focus_and_light("ashel", "focused"))
image ashel alarmed    = At("images/ashel alarmed.webp",    expr_alarmed,    char_focus_and_light("ashel", "alarmed"))
image ashel hurt       = At("images/ashel hurt.webp",       expr_hurt,       char_focus_and_light("ashel", "hurt"))
image ashel determined = At("images/ashel determined.webp", expr_determined, char_focus_and_light("ashel", "determined"))
image ashel proud      = At("images/ashel proud.webp",      expr_proud,      char_focus_and_light("ashel", "proud"))

# XOCHIT (6)
image xochtl neutral   = At("images/xochtl neutral.webp",   expr_neutral,    char_focus_and_light("xochtl", "neutral"))
image xochtl warm      = At("images/xochtl warm.webp",      expr_warm,       char_focus_and_light("xochtl", "warm"))
image xochtl focused   = At("images/xochtl focused.webp",   expr_focused,    char_focus_and_light("xochtl", "focused"))
image xochtl stern     = At("images/xochtl stern.webp",     expr_stern,      char_focus_and_light("xochtl", "stern"))
image xochtl hurt      = At("images/xochtl hurt.webp",      expr_hurt,       char_focus_and_light("xochtl", "hurt"))
image xochtl proud     = At("images/xochtl proud.webp",     expr_proud,      char_focus_and_light("xochtl", "proud"))

# CLARA (6) — raw PNGs face right; normalize with sprite_face_left so base orientation matches Koraba & Xochit
transform sprite_face_left:
    subpixel True
    xzoom -1.0

image laylay neutral     = At("images/laylay neutral.webp",     sprite_face_left, expr_neutral,     char_focus_and_light("laylay", "neutral"))
image laylay calculating = At("images/laylay calculating.webp", sprite_face_left, expr_calculating, char_focus_and_light("laylay", "calculating"))
image laylay smirk       = At("images/laylay smirk.webp",       sprite_face_left, expr_smirk,       char_focus_and_light("laylay", "smirk"))
image laylay defensive   = At("images/laylay defensive.webp",   sprite_face_left, expr_defensive,   char_focus_and_light("laylay", "defensive"))
image laylay stern       = At("images/laylay stern.webp",       sprite_face_left, expr_stern,       char_focus_and_light("laylay", "stern"))
image laylay alarmed     = At("images/laylay alarmed.webp",     sprite_face_left, expr_alarmed,     char_focus_and_light("laylay", "alarmed"))


################################################################################
## 4. Theater Blocking Slots & Shot Sizes (Static, Bottom-Anchored)
## Also overrides built-in `right`, `left`, and `center` so all chapter scripts
## automatically use the theatrical Rule-of-Thirds framing with stage-left inward flip.

init 10:
    transform right:
        subpixel True
        xalign 0.88 yalign 1.0
        xzoom 1.0 zoom 1.0 yoffset 0 xoffset 0 alpha 1.0

    transform left:
        subpixel True
        xalign 0.12 yalign 1.0
        xzoom -1.0 zoom 1.0 yoffset 0 xoffset 0 alpha 1.0

    transform center:
        subpixel True
        xalign 0.50 yalign 1.0
        xzoom 1.0 zoom 1.0 yoffset 0 xoffset 0 alpha 1.0

    transform center_left:
        subpixel True
        xalign 0.50 yalign 1.0
        xzoom 1.0 zoom 1.0 yoffset 0 xoffset 0 alpha 1.0

    transform center_right:
        subpixel True
        xalign 0.50 yalign 1.0
        xzoom -1.0 zoom 1.0 yoffset 0 xoffset 0 alpha 1.0

## Asymmetric Rule-of-Thirds Stage Slots
transform stage_right:
    subpixel True
    xalign 0.88 yalign 1.0
    xzoom 1.0 zoom 1.0 yoffset 0 xoffset 0 alpha 1.0

transform stage_left:
    subpixel True
    xalign 0.12 yalign 1.0
    xzoom 1.0 zoom 1.0 yoffset 0 xoffset 0 alpha 1.0

## Flips a 3/4 character horizontally on stage left so they face inward toward stage right
transform stage_left_flip:
    subpixel True
    xalign 0.12 yalign 1.0
    xzoom -1.0 zoom 1.0 yoffset 0 xoffset 0 alpha 1.0

transform stage_center:
    subpixel True
    xalign 0.50 yalign 1.0
    xzoom 1.0 zoom 1.0 yoffset 0 xoffset 0 alpha 1.0

## Close-Up Bust Framing (crops the 560x880 waist-up render into a tight 1.42x bust shot)
transform closeup_right:
    subpixel True
    xalign 0.80 yalign 1.0
    zoom 1.42 yoffset 260 xoffset 0

transform closeup_left:
    subpixel True
    xalign 0.20 yalign 1.0
    xzoom -1.0 zoom 1.42 yoffset 260 xoffset 0

transform closeup_center:
    subpixel True
    xalign 0.50 yalign 1.0
    zoom 1.42 yoffset 260 xoffset 0

## Power & Isolation Framing
transform imposing_center:
    subpixel True
    xalign 0.52 yalign 1.0
    zoom 1.18 yoffset 90 xoffset 0

transform imposing_right:
    subpixel True
    xalign 0.82 yalign 1.0
    zoom 1.16 yoffset 85 xoffset 0

transform lurk_right:
    subpixel True
    xalign 0.94 yalign 1.0
    zoom 0.93 yoffset 20 xoffset 0

## Bespoke Story Framing (Static — No Motion)
transform enter_shadow(x_pos=0.82):
    subpixel True
    xalign x_pos yalign 1.0
    alpha 1.0 zoom 1.0 yoffset 0 xoffset 0

transform enter_glitch(x_pos=0.86):
    subpixel True
    xalign x_pos yalign 1.0
    alpha 1.0 zoom 1.0 yoffset 0 xoffset 0

transform enter_whisper_left:
    subpixel True
    xalign 0.28 yalign 1.0
    xzoom -1.0 alpha 1.0 zoom 1.06 yoffset 14 xoffset 0

transform exit_ghost:
    subpixel True
    xoffset 35 yoffset 0 alpha 0.32 matrixcolor (SaturationMatrix(0.0) * BrightnessMatrix(0.15))


################################################################################
## 5. Static Camera Framing (for `camera at ...` or Stage Lab container)
## Positive yoffset keeps zoomed-in frames anchored to the bottom of the screen
## so camera zoom never lifts the stage or creates bottom gaps.

transform cam_reset:
    subpixel True
    xalign 0.5 yalign 0.5
    zoom 1.0 xoffset 0 yoffset 0 matrixcolor IdentityMatrix()

transform cam_push_in:
    subpixel True
    xalign 0.5 yalign 0.5
    zoom 1.08 xoffset 0 yoffset 40 matrixcolor IdentityMatrix()

transform cam_intimate:
    subpixel True
    xalign 0.5 yalign 0.5
    zoom 1.15 xoffset 0 yoffset 75 matrixcolor IdentityMatrix()

transform cam_dutch_spiral:
    subpixel True
    xalign 0.5 yalign 0.5
    zoom 1.09 xoffset 0 yoffset 45 matrixcolor (ContrastMatrix(1.08) * SaturationMatrix(0.88))

transform cam_red_alert:
    subpixel True
    xalign 0.5 yalign 0.5
    zoom 1.05 xoffset 0 yoffset 25 matrixcolor (TintMatrix("#EED4B4") * ContrastMatrix(1.10))
